<!DOCTYPE HTML>  
<html>
<head>
  <title>NDC Company</title>
  <h1 ><img src="companylogo.jpg" alt="company" width="200" height="200"></h1>
</head>
<body> 
<table align="center">

<?php
echo "Welcome to NDC Company";
?>
<tr>
<td><a href="REGISTRATION.php"> Registration </a></td>
<td><a href="LOGIN.php"> Login </a></td>
<td><a href="PUBLIC HOME.php"> Home </a></td>
</tr>
</table>
<?php include 'footer.php';?>
 </body>
</html>
